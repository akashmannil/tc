B2C Samples for MSAL JS library and documentation for Azure AD B2C scenarios is maintained [here](https://github.com/Azure-Samples/active-directory-b2c-javascript-msal-singlepageapp).
