# MSAL Angularjs Wrapper

## install dependencies
Run `npm install` from the root of the repository.

## Development server
Run `npm start` for a dev server. Navigate to `http://localhost:44302/`. The app will automatically reload if you change any of the source files.
