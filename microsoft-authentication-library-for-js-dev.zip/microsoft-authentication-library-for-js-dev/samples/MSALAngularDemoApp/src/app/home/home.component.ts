import {Component} from '@angular/core';

@Component({
    template: `
    <p>This sample demonstrates how to take advantage of MSAL Angular for adding Azure AD authentication to your Angular apps.</p>`
})

export class HomeComponent {

  constructor( ){

  }


  ngOnInit() {

  }
}
