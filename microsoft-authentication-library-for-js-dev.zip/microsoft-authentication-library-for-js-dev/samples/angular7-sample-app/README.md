# MSAL - Angular 7 Sample App

This is a sample Angular application (built with version 7 of the Angular CLI) that demonstrates basic usage of `msal` and `@azure/msal-angular`.

## Installing MSAL

1. `npm install msal@beta @azure/msal-angular@alpha`
2.
