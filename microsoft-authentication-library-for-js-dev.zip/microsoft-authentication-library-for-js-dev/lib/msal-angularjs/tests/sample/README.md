# AngularJS MSAL Wrapper

## Development server
Run `npm install`
Run `npm start` for a dev server. Navigate to `http://localhost:44302/`. The app will automatically reload if you change any of the source files.