# 0.1.2
* Added support to handle the issue of the session storage and local storage getting cleared in IE and edge browsers during redirects across different security zones. This can be enabled by setting storeAuthStateInCookie flag in config to true. Default value is false.  
https://github.com/AzureAD/microsoft-authentication-library-for-js/issues/347


# 0.1.1
* Upgraded to latest msal-core version 0.2.1


# 0.1.0
Preview Release 
