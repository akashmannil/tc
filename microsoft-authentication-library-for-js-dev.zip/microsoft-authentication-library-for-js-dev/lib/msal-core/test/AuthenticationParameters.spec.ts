import { expect } from "chai";
import sinon from "sinon";

describe("Authentication Parameters (A.K.A. Request Object)", function () {


});