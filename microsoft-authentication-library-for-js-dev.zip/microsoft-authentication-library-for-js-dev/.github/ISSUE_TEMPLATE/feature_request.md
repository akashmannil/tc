---
name: Feature request
about: Suggest a feature for one of our libraries.
title: ''
labels: feature
assignees: ''

---

Please follow the issue template below. Failure to do so will result in a delay in answering your question.

## Library
- [ ] `msal@1.x.x` or `@azure/msal@1.x.x`
- [ ] `@azure/msal-browser@2.x.x`
- [ ] `@azure/msal-angular@0.x.x`
- [ ] `@azure/msal-angular@1.x.x`
- [ ] `@azure/msal-angularjs@1.x.x`

## Description
Please describe the functionality or improvement you would like to see added.
