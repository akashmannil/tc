export class FlightBooking{
    bookingId:any;
    passengerName:any;
    noOfTickets:any;
    totalAmount:any; 
    flightId:any;
    bookings:any;
    aircraftName : any;
    availableSeats : any;
    fare : any;
    status : any;
}