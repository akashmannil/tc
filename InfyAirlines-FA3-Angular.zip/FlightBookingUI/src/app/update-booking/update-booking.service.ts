import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class UpdateBookingService {

  constructor(private http: HttpClient) { }

  updateBooking(formData): Observable<any> {
    //make an http put call with the given url by passing the bookingId of the formData and also the formData 

    return 
  }
}
