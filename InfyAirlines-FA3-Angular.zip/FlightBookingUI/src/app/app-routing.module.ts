import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
/* Import the necessary modules here */ 

/* Create the necessary routes here */
export const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
