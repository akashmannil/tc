import { Component, OnInit, Output, EventEmitter } from '@angular/core';
/* Import the required modules here */ 

@Component({
  selector: 'app-view-flights',
  templateUrl: './view-flights.component.html',
  styleUrls: ['./view-flights.component.css']
})

export class ViewFlightsComponent implements OnInit {
  flightDetails;

  @Output() flightToEmit = new EventEmitter();

  imageUrl = ["../../assets/a1.jpg", "../../assets/a2.jpg", "../../assets/a3.jpg"];
  errorMessage = null;

  /* Inject the required dependency here */
  constructor() { }

  ngOnInit() { }

  getAllFlights() {
    // implement the getAllFlights method by invoking the view method of ViewDetailsService
    // and correspondingly populate flightDetails and errorMessage 
  }

  sendFlightData(flight) {
    // emit the flight object using the flightToEmit event
  }

}
