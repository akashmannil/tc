const { Schema } = require("mongoose");
const Mongoose = require("mongoose")
Mongoose.Promise = global.Promise;
Mongoose.set('useCreateIndex', true)
const url = "mongodb://localhost:27017/TalentCapture_DB";

const accessSchema = Schema({
    employeeId: {type:String,required:true,unique:true},
    employeeName: {type:String,required:true},
    contactNo: {type:Number,required:true,unique:true},
    accessType: { type: String, enum: ['SuperAdmin', 'Admin', 'User'] ,required:true}
}, { collection: "Access" });

const dynamicDataSchema = Schema({
    domain:{type:Array, default:[]},
    plcSkills:{type:Array, default:[]},
    scadaSkills:{type:Array, default:[]},
    dcsSkills:{type:Array, default:[]},
    hmiSkills:{type:Array, default:[]},
    otherSkills:{type:Array, default:[]}
   
},{collection:'DynamicData'})
const detailsSchema = Schema({
    employeeId: {type:String,unique:true},
    employeeName: String,
    employeeEmail:{type:String,unique:true},
    contactNo: {type:Number,min:1000000000,max:9999999999,unique:true},
    allocatedToProject:{type:Object, default:{allocation:false,percentageAllocation:0}},
    totalExperience:Number,
    infosysExperience:Number,
    controlSystemExperience:Number,
    domain:{type:Array, default:[]},
    plcSkills:{type:Array, default:[]},
    scadaSkills:{type:Array, default:[]},
    dcsSkills:{type:Array, default:[]},
    hmiSkills:{type:Array, default:[]},
    otherSkills:{type:Array, default:[]},
}, { collection: "Details" })

let collection = {};

collection.getAccessCollection = () => {
    return Mongoose.connect(url, { useNewUrlParser: true }).then((database) => {
        return database.model('Access', accessSchema)
    }).catch((error) => {
        let err = new Error("Could not connect to Database");
        err.status = 500;
        throw err;
    })
}

collection.getDetailsCollection = () => {
    return Mongoose.connect(url, { useNewUrlParser: true }).then((database) => {
        return database.model('Details', detailsSchema)
    }).catch((error) => {
        let err = new Error("Could not connect to Database");
        err.status = 500;
        throw err;
    })
}

collection.getDynamicDataCollection = () => {
    return Mongoose.connect(url, { useNewUrlParser: true }).then((database) => {
        return database.model('DynamicData', dynamicDataSchema)
    }).catch((error) => {
        let err = new Error("Could not connect to Database");
        err.status = 500;
        throw err;
    })
}


module.exports = collection;