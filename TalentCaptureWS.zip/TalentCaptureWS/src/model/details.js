const dbModel = require('../utilities/connection');

const detailsDb = {}

detailsDb.getData = (id) => {
    return dbModel.getDetailsCollection().then(model => {
        return model.findOne({ $or: [{ employeeId: id }, { employeeName: id }, { contactNo: id }] }
            , { _id: false }).then(value => {
                if (value)
                    return value;
                else
                    return null;
            })
    })
}


detailsDb.addDetails = (details) => {
    return dbModel.getDetailsCollection().then(model => {
        return model.findOne({ employeeId: details.employeeId }, { _id: false }).then(value => {
            if (value) {
                let err = new Error('Employee details Exists. Please use Update option.');
                err.status = 501;
                throw err;
            }
            else {
                return model.create(details).then(value => {
                    console.log(value)
                    if (value)
                        return value;
                    else
                        return null;
                })
            }
        })
    })
}


detailsDb.updateDetails = (details) => {
    return dbModel.getDetailsCollection().then(model => {
        return model.findOne({ employeeId: details.employeeId }).then(pDetails => {
            if (pDetails) {
                return model.deleteOne({ employeeId: details.employeeId }).then(() => {
                    return model.create(details).then(value => {
                        if (value)
                            return value;
                        else
                            return null;
                    })
                })
            }
            else
                return null;
        })
    })
}


detailsDb.getDynamicData=()=>{
    return dbModel.getDynamicDataCollection().then(model=>{
        return model.findOne({},{_id:0,__v:0}).then(value=>{
            if(value)
            return value;
            else
            return null;
        })
    })
}



detailsDb.setupDynamicData = () => {
    let a = {};
    a.domain = [];
    a.plcSkills = [];
    a.scadaSkills = [];
    a.dcsSkills = [];
    a.hmiSkills = [];
    a.otherSkills = [];
    return dbModel.getDetailsCollection().then(model => {
        return dbModel.find({}, {
            employeeId: 0, employeeName: 0, employeeEmail: 0, contactNo: 0,
            allocatedToProject: 0, totalExperience: 0, infosysExperience: 0, controlSystemExperience: 0, __v: 0
        }).then(value => {
            if (value.length < 0)
                return null;
            else {
                let domainArr = plcSkillArr = dcsSkillArr = scadaSkillArr = hmiSkillArr = otherSkillArr = [];
                value.forEach(val => {
                    let t1 = t2 = t3 = t4 = t5 = t6 = 0;
                    val.domain.forEach(dom => {
                        t1=0
                        a.domain.forEach(v=>{
                            if(dom.selectedDomain==v)
                            t1=1;
                        })
                        if (t1 == 0) { domainArr.push(dom.selectedDomain) }
                    })
                    val.plcSkills.forEach(plcSkills => {
                        t2=0
                        a.plcSkills.forEach(v=>{
                            if(plcSkills.selectedPLC==v)
                            t2=1;
                        })
                        if (t2 == 0) { plcSkillArr.push(plcSkills.selectedPLC) }
                    })
                    val.scadaSkills.forEach(scadaSkills => {
                        t3=0
                        a.scadaSkills.forEach(v=>{
                            if(scadaSkills.selectedSCADA==v)
                            t3=1;
                        })
                        if (t3 == 0) { scadaSkillArr.push(scadaSkills.selectedSCADA) }
                    })
                    val.dcsSkills.forEach(dcsSkills => {
                        t4=0
                        a.dcsSkills.forEach(v=>{
                            if(dcsSkills.selectedDCS==v)
                            t4=1;
                        })
                        if (t4 == 0) { dcsSkillArr.push(dcsSkills.selectedDCS) }
                    })
                    val.hmiSkills.forEach(hmiSkills => {
                        t5=0
                        a.hmiSkills.forEach(v=>{
                            if(hmiSkills.selectedHMI==v)
                            t5=1;
                        })
                        if (t5 == 0) { hmiSkillArr.push(hmiSkills.selectedHMI) }
                    })
                    val.otherSkills.forEach(otherSkills => {
                        t6=0
                        a.otherSkills.forEach(v=>{
                            if(otherSkills.selectedOther==v)
                            t6=1;
                        })
                        if (t6 == 0) { otherSkillArr.push(otherSkills.selectedOther) }
                    })
                })
                a.domain = domainArr;
                a.plcSkills = plcSkillArr;
                a.scadaSkills = scadaSkillArr;
                a.dcsSkills = dcsSkillArr;
                a.hmiSkills = hmiSkillArr;
                a.otherSkills = otherSkillArr;
                return dbModel.getDynamicDataCollection().then(dynamicData => {
                    return dynamicData.deleteMany().then(() => {
                        return dynamicData.create(a).then(data => {
                            if (data)
                                return data;
                            else
                                return null;
                        })
                    })
                })
            }
        })
    })
}





// detailsDb.generateId = () => {
//     return dbModel.getFlightCollection().then((model) => {
//         return model.distinct("bookings.bookingId").then((ids) => {
//             let bId = Math.max(...ids);
//             return bId + 1;
//         })
//     })
// }

// detailsDb.checkCustomer = (customerId) => {
//     return dbModel.getCustomerCollection().then((model) => {
//         return model.findOne({ customerId: customerId }).then((customer) => {
//             if (!customer) { console.log(customerId); return null }
//             else return customer;
//         })
//     })
// }


// detailsDb.checkBooking = (bookingId) => {
//     return dbModel.getFlightCollection().then((model) => {
//         return model.findOne({ "bookings.bookingId": bookingId }).then((flightbooking) => {
//             if (!flightbooking) return null;
//             else return flightbooking;
//         })
//     })
// }

// detailsDb.checkAvailability = (flightId) => {
//     return dbModel.getFlightCollection().then((model) => {
//         return model.findOne({ flightId: flightId }).then((flightRecord) => {
//             if (!flightRecord) return null;
//             else return flightRecord;
//         })
//     })
// }

// detailsDb.updateCustomerWallet = (customerId, bookingCost) => {
//     return dbModel.getCustomerCollection().then((model) => {
//         return model.updateOne({ customerId: customerId }, { $inc: { walletAmount: -bookingCost } })
//             .then((saved) => {
//                 if (saved.nModified == 1) { console.log(true); return true }
//                 else return false
//             })
//     })
// }

// detailsDb.bookFlight = (flightBooking) => {
//     return dbModel.getFlightCollection().then((model) => {
//         return detailsDb.generateId().then((bid) => {
//             flightBooking.bookingId = bid;
//             return model.updateOne({ flightId: flightBooking.flightId }, { $push: { bookings: flightBooking } })
//                 .then((data) => {
//                     if (data.nModified == 1) {
//                         return model.updateOne({ flightId: flightBooking.flightId }, { $inc: { availableSeats: -flightBooking.noOfTickets } })
//                             .then((saved) => {
//                                 if (saved.nModified == 1) {
//                                     return detailsDb.updateCustomerWallet(flightBooking.customerId, flightBooking.bookingCost)
//                                         .then((bookingStatus) => {
//                                             if (bookingStatus) return flightBooking.bookingId;
//                                             else {
//                                                 let err = new Error("wallet not updated");
//                                                 err.status = 400;
//                                                 throw err;
//                                             }
//                                         })
//                                 } else {
//                                     let err = new Error("seats not updated");
//                                     err.status = 400;
//                                     throw err;
//                                 }
//                             })
//                     } else {
//                         let err = new Error("Booking failed");
//                         err.status = 400;
//                         throw err;
//                     }
//                 })
//         })
//     })
// }

// detailsDb.getAllBookings = () => {
//     return dbModel.getFlightCollection().then((model) => {
//         return model.find({}, {}).then((bookings) => {
//             if (!bookings || bookings.length == 0) return null;
//             else return bookings;
//         })
//     })
// }

// detailsDb.customerBookingsByFlight = (customerId, flightId) => {
//     return dbModel.getFlightCollection().then((model) => {
//         return model.findOne({ flightId: flightId }, { _id: 0, bookings: 1 })
//             .then((bookings) => {
//                 let myBookings = []
//                 for (let booking of bookings.bookings) {
//                     if (booking.customerId == customerId) {
//                         myBookings.push(booking);
//                     } else continue;
//                 }
//                 if (!myBookings || myBookings.length == 0) return null;
//                 else return myBookings;
//             })
//     })
// }

// detailsDb.getbookingsByFlightId = (flightId) => {
//     return dbModel.getFlightCollection().then((model) => {
//         return model.find({ flightId: flightId }, { _id: 0, bookings: 1 })
//             .then((bookings) => {
//                 if (!bookings || bookings.length == 0) return null;
//                 else return bookings;
//             })
//     })
// }

// detailsDb.updateBooking = (bookingId, noOfTickets) => {
//     return dbModel.getFlightCollection().then((model) => {
//         return model.updateOne({ "bookings.bookingId": bookingId }, { $inc: { "bookings.$.noOfTickets": noOfTickets, availableSeats: -noOfTickets } }).then((updated) => {
//             if (updated.nModified == 1) {
//                 return model.findOne({ "bookings.bookingId": bookingId }).then((flight) => {
//                     if (flight) {
//                         return model.updateOne({ "bookings.bookingId": bookingId }, { $inc: { "bookings.$.bookingCost": noOfTickets * flight.fare } }).then((saved) => {
//                             if (saved.nModified == 1) {
//                                 for (let booking of flight.bookings) {
//                                     if (booking.bookingId == bookingId) { custId = booking.customerId; break; }
//                                     else continue;
//                                 }
//                                 return dbModel.getCustomerCollection().then((model1) => {
//                                     return model1.updateOne({ customerId: custId }, { $inc: { walletAmount: -(noOfTickets * flight.fare) } }).then((wupdated) => {
//                                         if (wupdated.nModified == 1) {
//                                             return detailsDb.checkAvailability(flight.flightId).then((flight) => {
//                                                 return flight;
//                                             })
//                                         }
//                                         else return null;
//                                     })
//                                 })
//                             }
//                         })
//                     }
//                 })
//             }
//         })
//     })
// }

// // detailsDb.deleteBooking = (id) => {
// //     return dbModel.getFlightCollection().then(model => {
// //         return model.deleteOne({ bookingId: id }).then(deleted => {
// //             if (deleted.n > 0) return id;
// //             else return null;
// //         })
// //     })
// // }

// detailsDb.deleteBooking = (id) =>{
//     return dbModel.getFlightCollection().then((model) =>{
//         return model.findOne({"bookings.bookingId":id}).then((flight) =>{
//             if(flight){
//                 console.log(flight,":",id)
//                 return model.updateOne({"bookings.bookingId":id},{ $pull :{bookings : {bookingId : id} }}).then((res)=>{
//                     console.log("asd:",res)
//                     if(res.nModified==1){
//                         return flight
//                     }
//                     else{
//                         return null
//                     }
//                 }).catch(err=>{console.log(err);return null;})
//             }
//         })
//     }) 
// }





module.exports = detailsDb;