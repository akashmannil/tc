const collection = require('../utilities/connection');

const accessDb = [
    {
        employeeId: "P1001",
        employeeName: "Tom",
        contactNo: 9083927482,
        accessType: "SuperAdmin"
    },
    {
        employeeId: "G1001",
        employeeName: "John",
        contactNo: 9083927422,
        accessType: "Admin"
    },
    {
        employeeId: "S1001",
        employeeName: "Steve",
        contactNo: 9083227422,
        accessType: "User"
    }
]

const detailsDb = [
    {
        employeeId: "1000",
        employeeName: "User 1",
        employeeEmail: "user1@gmail.com",
        contactNo: 9999999999,
        allocatedToProject: { allocation: true, percentageAllocation: 7 },
        totalExperience: 2.0,
        infosysExperience: 1.2,
        controlSystemExperience: 1.2,
        domain: { type: Object, default: {} },
        plcSkills: { type: Object, default: {} },
        scadaSkills: { type: Object, default: {} },
        dcsSkills: [{ selectedDCS: 'PCS-7, Siemens', experience: 0.5 },
        { selectedDCS: 'MARK-VI, GE', experience: 1.0 },
        { selectedDCS: 'ASPA, Alstom', experience: 0.2 },
        { selectedDCS: '800XA, ABB', experience: 0.8 }],
        hmiSkills: { type: Object, default: {} },
        otherSkills: { type: Object, default: {} },
    },
    {
        employeeId: "1001",
        employeeName: "User 2",
        employeeEmail: "user2@gmail.com",
        contactNo: 9999999998,
        allocatedToProject: { allocation: true, percentageAllocation: 77 },
        totalExperience: 12.0,
        infosysExperience: 6.9,
        controlSystemExperience: 10,
        // domain: { type: Object, default: {} },
        // plcSkills: { type: Object, default: {} },
        // scadaSkills: { type: Object, default: {} },
        // dcsSkills: { type: Object, default: {} },
        // hmiSkills: { type: Object, default: {} },
        // otherSkills: { type: Object, default: {} },
    },
    {
        employeeId: "1002",
        employeeName: "User 2",
        employeeEmail: "user2@gmail.com",
        contactNo: 9999999997,
        // allocatedToProject: { allocation: true, percentageAllocation: 7 },
        totalExperience: 0.1,
        infosysExperience: 0.1,
        controlSystemExperience: 0,
        // domain: { type: Object, default: {} },
        // plcSkills: { type: Object, default: {} },
        // scadaSkills: { type: Object, default: {} },
        // dcsSkills: { type: Object, default: {} },
        // hmiSkills: { type: Object, default: {} },
        // otherSkills: { type: Object, default: {} },
    },


]

const dynamicDatadb = [{

},]

exports.setupDb = () => {
    return collection.getAccessCollection().then((access) => {
        return access.deleteMany().then(() => {
            return access.insertMany(accessDb).then(() => {
                return collection.getDetailsCollection().then((details) => {
                    return details.deleteMany().then(() => {
                        return details.insertMany(detailsDb).then((data) => {
                            return collection.getDynamicDataCollection().then(dynamicData => {
                                return dynamicData.deleteMany().then(() => {
                                    return dynamicData.insertMany().then(data => {
                                        if (data) return "Insertion Successful"
                                        else {
                                            let err = new Error("Insertion failed");
                                            err.status = 400;
                                            throw err;
                                        }
                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    })
}